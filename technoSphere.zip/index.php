<?php include 'inc/header.php'; ?>
<?php include 'inc/slider.php'; ?>
<div class="main container">
	<div class="content">
		<hr />
		<div class="py-4">
			<h3 class="text-center text-uppercase">Feature Products</h3>
			<div class="clear"></div>
		</div>
		<div class="row">
			<?php
			$getFpd = $pd->getFeaturedProduct();
			if ($getFpd) {
				while ($result = $getFpd->fetch_assoc()) {
			?>

					<div class="col-lg-3 border p-2">
						<div style="height:100px; margin:35px 0px;"><a href="details.php?proid=<?php echo $result['productId']; ?>"><img width="130" src="admin/<?php echo $result['image']; ?>" alt="" /></a></div>
						<div style="height: 120px;">
							<h5><?php echo $result['productName']; ?></h5>
							<p><?php echo $fm->textShorten($result['body'], 60); ?></p>
							<p><span class="price">Rs.<?php echo $result['price']; ?></span></p>
						</div>

						<div class="button"><span><a class='btn btn-sm btn-success' href="details.php?proid=<?php echo $result['productId']; ?>" class="details">Details</a></span></div>
					</div>
			<?php }
			} ?>

		</div>
		<div class="py-5">
			<h3 class="text-uppercase text-center">New Products</h3>
			<div class="clear"></div>
		</div>
		<div class="row">
			<?php
			$getNpd = $pd->getNewProduct();
			if ($getNpd) {
				while ($result = $getNpd->fetch_assoc()) {
			?>
					<div class="col-lg-3 border p-2">
						<div style="height:100px; margin:35px 0px;"><a href="details.php?proid=<?php echo $result['productId']; ?>"><img class="text-center" width="130" src="admin/<?php echo $result['image']; ?>" /></a></div>
						<div style="height: 80px;">
							<h5><?php echo $result['productName']; ?></h5>
							<p><span class="price">Rs.<?php echo $result['price']; ?></span></p>
						</div>
						<div class="button"><span><a class='btn btn-sm btn-success' href="details.php?proid=<?php echo $result['productId']; ?>" class="details">Details</a></span></div>
					</div>
			<?php }
			} ?>

		</div>
	</div>
</div>

<?php include 'inc/footer.php'; ?>