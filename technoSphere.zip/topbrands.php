<?php include 'inc/header.php'; ?>

<div class="main">
	<div class="container">
		<div class="content">
			<div class="py-4">
				<h3>Iphone</h3>
				<hr>
				<div class="clear"></div>
			</div>

			<div class="row">
				<?php
				$getTop4 = $pd->getTopbrandIphone();
				if ($getTop4) {
					while ($result = $getTop4->fetch_assoc()) {
				?>

						<div class="col-lg-3 border p-3">
							<a href="details.php?proid=<?php echo $result['productId']; ?>"><img width="140" src="admin/<?php echo $result['image']; ?>" alt="" /></a>
							<h2><?php echo $result['productName']; ?></h2>
							<p><?php echo $fm->textShorten($result['body'], 60); ?></p>
							<p><span class="price">Rs.<?php echo $result['price']; ?></span></p>
							<div class="button"><span><a class='btn btn-sm btn-success' href="details.php?proid=<?php echo $result['productId']; ?>" class="details">Details</a></span></div>
						</div>
				<?php }
				} ?>
			</div>
			<div>
				<div class="py-5">
					<h3>Acer</h3>
					<hr>
				</div>
				<div class="clear"></div>
			</div>
			<div class="row">

				<?php
				$getTop1 = $pd->getTopbrandAcer();
				if ($getTop1) {
					while ($result = $getTop1->fetch_assoc()) {
				?>
						<div class="col-lg-3 border p-3">
							<div style="height:100px;" class="mb-4">
								<a href="details.php?proid=<?php echo $result['productId']; ?>"><img width="140" src="admin/<?php echo $result['image']; ?>" alt="" /></a>
							</div>
							<div style="height: 150px; ">
								<h2><?php echo $result['productName']; ?></h2>
								<p><?php echo $fm->textShorten($result['body'], 60); ?></p>
								<p><span class="price">Rs.<?php echo $result['price']; ?></span></p>
							</div>
							<div class="button">
								<span><a class='btn btn-sm btn-success' href="details.php?proid=<?php echo $result['productId']; ?>" class="details">Details</a></span>
							</div>
						</div>
				<?php }
				} ?>

			</div>

			<div>
				<div class="py-5">
					<h3>Samsung</h3>
				</div>
				<div class="clear"></div>
			</div>
			<div class="row">
				<?php
				$getTop2 = $pd->getTopbrandSamsung();
				if ($getTop2) {
					while ($result = $getTop2->fetch_assoc()) {


				?>

						<div class="col-lg-3 border p-3">
							<a href="details.php?proid=<?php echo $result['productId']; ?>"><img width="140" src="admin/<?php echo $result['image']; ?>" alt="" /></a>
							<h2><?php echo $result['productName']; ?></h2>
							<p><?php echo $fm->textShorten($result['body'], 60); ?></p>
							<p><span class="price">Rs.<?php echo $result['price']; ?></span></p>
							<div class="button"><span><a class='btn btn-sm btn-success' href="details.php?proid=<?php echo $result['productId']; ?>" class="details">Details</a></span></div>
						</div>
				<?php }
				} ?>

			</div>


			<div class="py-5">
				<h3>Canon</h3>
				<hr>
			</div>
			<div class="clear"></div>

			<div class="row">
				<?php
				$getTop3 = $pd->getTopbrandCanon();
				if ($getTop3) {
					while ($result = $getTop3->fetch_assoc()) {
				?>
						<div class="col-lg-3 border p-3">
							<a href="details.php?proid=<?php echo $result['productId']; ?>"><img src="admin/<?php echo $result['image']; ?>" alt="" /></a>
							<h2><?php echo $result['productName']; ?></h2>
							<p><?php echo $fm->textShorten($result['body'], 60); ?></p>
							<p><span class="price">Rs.<?php echo $result['price']; ?></span></p>
							<div class="button"><span><a class='btn btn-sm btn-success' href="details.php?proid=<?php echo $result['productId']; ?>" class="details">Details</a></span></div>
						</div>
				<?php }
				} ?>

			</div>
		</div>
	</div>
</div>
<?php include 'inc/footer.php'; ?>