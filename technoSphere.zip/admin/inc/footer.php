 <footer class="py-2 text-white">
     <p>
         &copy; Copyright <a href="#" class="text-white">TechnoSphere</a>. All Rights Reserved.
     </p>
 </footer>

 </body>

 </html>