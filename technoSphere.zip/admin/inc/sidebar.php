<div class="grid_2">
    <div class="box sidemenu">
        <div class="block">
            <ul class="section menu">
                <!--  <li><a class="menuitem">Site Option</a>
                    <ul class="submenu">
                        <li><a href="titleslogan.php">Title & Slogan</a></li>
                        <li><a href="social.php">Social Media</a></li>
                        <li><a href="copyright.php">Copyright</a></li>
                        
                    </ul>
                </li>
				
                 <li><a class="menuitem">Update Pages</a>
                    <ul class="submenu">
                        <li><a>About Us</a></li>
                        <li><a>Contact Us</a></li>
                    </ul>
                </li>
				<li><a class="menuitem">Slider Option</a>
                    <ul class="submenu">
                        <li><a href="slideradd.php">Add Slider</a> </li>
                        <li><a href="sliderlist.php">Slider List</a> </li>
                    </ul>
                </li> -->
                <hr />
                
                <li><a href="catlist.php">Category Manage</a> </li>
                <li><a href="brandlist.php">Brand Manage</a> </li>
                
                
                <li><a href="productlist.php">Product Manage</a> </li>
                <li><a href="sliderlist.php">Order Manage</a> </li>
                </li>
            </ul>
        </div>
    </div>
</div>