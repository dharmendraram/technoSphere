Admin Login
username: nareshtharu
password: 122713

Customer
username:shuzeet15@gmail.com
password:sujit123